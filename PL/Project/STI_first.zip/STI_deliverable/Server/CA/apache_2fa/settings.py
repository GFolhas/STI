EXPIRATION_TIME = 6*60*60    # require re-authentication every 6 hours
